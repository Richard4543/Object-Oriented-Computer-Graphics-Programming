package com.mycompany.a3;

import com.codename1.ui.events.ActionEvent;
import com.codename1.ui.Command;

/**
 * The Class PositionCommand.
 */
public class PositionCommand extends Command {

	/** The g. */
	private Game g;

	/** The mv. */
	private MapView mv;

	/**
	 * Instantiates a new position command.
	 *
	 * @param g the g
	 * @param mv the mv
	 */
	public PositionCommand(Game g, MapView mv) {
		super("position");
		this.g = g;
		this.mv = mv;
	}

	/* (non-Javadoc)
	 * @see com.codename1.ui.Command#actionPerformed(com.codename1.ui.events.ActionEvent)
	 */
	@Override
	public void actionPerformed(ActionEvent Events) {
		if(g.isPaused() == true) {
			mv.positionButtonPressed();
			//System.out.println("Select an object");

		} 
		else{
			//mv.removePointerPressedListener(this);
			return;
		}
	}
}
