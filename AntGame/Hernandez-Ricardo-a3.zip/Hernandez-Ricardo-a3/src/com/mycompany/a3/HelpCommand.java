package com.mycompany.a3;

import com.codename1.ui.events.ActionEvent;
import com.codename1.ui.Command;
import com.codename1.ui.Dialog;

/**
 * The Class HelpCommand.
 */
public class HelpCommand extends Command{
	
	/**
	 * Instantiates a new help command.
	 */
	public HelpCommand() {
		super("Help");
	}
	
	/* (non-Javadoc)
	 * @see com.codename1.ui.Command#actionPerformed(com.codename1.ui.events.ActionEvent)
	 */
	public void actionPerformed(ActionEvent Events) {
		String aboutText = (""
		        + "\n" + "A: Accelerate"
		        + "\n" + "B: Brake"
		        + "\n" + "T: Clock tick"
		        + "\n" + "X: Exit game"
		        + "\n" + "R: Right turn"
		        + "\n" + "L: Left turn"
		        + "\n" + "D: Display Stats"
		        + "\n" + "M: Display objects"
		        + "\n" + "1...9: Flag Collision"
		        + "\n" + "F: Food collsion"
		        + "\n" + "G: Spider Collision");
		Command okayButton = new Command("Ok");
		
		Dialog.show("Help",  aboutText, okayButton);
	}
}
