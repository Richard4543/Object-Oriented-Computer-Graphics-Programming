package com.mycompany.a3;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Container;
import com.codename1.ui.layouts.BorderLayout;
import com.codename1.ui.plaf.Border;
import java.util.Observable;
import java.util.Observer;
import com.codename1.ui.Graphics;
import com.codename1.ui.geom.Point;


/**
 * The Class MapView.
 */
public class MapView extends Container implements Observer {

	/** The game objects. */
	private GameObjectCollection gameObjects;
	
	/** The obj. */
	private Fixed objectSelected;
	
	private Game b;
	
	private boolean positionButtonPressed;
	
	/** The px. */
	private int px;
	
	/** The py. */
	private int py;

	/**
	 * Instantiates a new map view.
	 */
	public MapView(Game b) {
		this.setLayout(new BorderLayout());
		this.getAllStyles().setBorder(Border.createLineBorder(2, ColorUtil.rgb(255, 0, 0)));
		this.b = b;
	}

	/* (non-Javadoc)
	 * @see com.codename1.ui.Container#paint(com.codename1.ui.Graphics)
	 */
	@Override
	public void paint(Graphics g) {
		super.paint(g);
		Point pCmpRelPrnt = new Point(this.getX(), this.getY());
		IIterator obj = gameObjects.getIterator();

		while(obj.hasNext()) {
			GameObject currobjects = (GameObject) obj.getNext();
			currobjects.draw(g, pCmpRelPrnt);
		}
	}
	
	public void positionButtonPressed() {
		positionButtonPressed = true;
	}

	/* (non-Javadoc)
	 * @see com.codename1.ui.Container#pointerPressed(int, int)
	 */
	@Override
	public void pointerPressed(int x, int y) {
		if(!b.isPaused()) {
			return;
		}
		if(objectSelected == null && !positionButtonPressed) {
			px = x - getParent().getAbsoluteX();
			py = y - getParent().getAbsoluteY();

			Point pCmpRelPrnt = new Point(getX(), getY()); 
			Point pPtrRelPrnt = new Point(px, py);
			IIterator obj = gameObjects.getIterator();
			while(obj.hasNext()) {
				GameObject object = (GameObject) obj.getNext();
				if(object instanceof Fixed) {
					//Fixed theObj = (Fixed) object;
					if(((Fixed) object).contains(pPtrRelPrnt, pCmpRelPrnt)) {
						objectSelected = (Fixed) object;
						objectSelected.setSelected(true);
						System.out.println("OBJECT SELECTED");
					}
				}
			}
		}else if(positionButtonPressed && objectSelected != null) {
			objectSelected.setLocation(x - getParent().getAbsoluteX() - getX(), y - getParent().getAbsoluteY() - getY());
			objectSelected.setSelected(false);
			positionButtonPressed = false;
			objectSelected = null;
		}
		else {
			positionButtonPressed = false;
		}
		repaint();
		System.out.println("clicked");
		
	}

	/* (non-Javadoc)
	 * @see java.util.Observer#update(java.util.Observable, java.lang.Object)
	 */
	@Override
	public void update(Observable observable, Object data) {
		GameWorld gw = (GameWorld) observable;
		gameObjects = gw.getCollection();
		gw.DisplayObjects();
		repaint();
	}
}
