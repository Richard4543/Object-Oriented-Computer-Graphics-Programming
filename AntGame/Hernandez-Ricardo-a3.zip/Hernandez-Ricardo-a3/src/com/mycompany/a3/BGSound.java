package com.mycompany.a3;

import com.codename1.ui.Display;
import java.io.InputStream; 
import com.codename1.media.Media;
import com.codename1.media.MediaManager;

/**
 * The Class BGSound.
 */
public class BGSound implements Runnable {
	
	/** The m. */
	private Media m;
	
	/* (non-Javadoc)
	 * @see java.lang.Runnable#run()
	 */
	@Override
	public void run() {
		// TODO Auto-generated method stub
		m.setTime(0);
		//m.setVolume(2);
		m.play();
		
	}
	
	/**
	 * Instantiates a new BG sound.
	 *
	 * @param fn the fn
	 */
	public BGSound(String fn) {
		try {
			InputStream input = Display.getInstance().getResourceAsStream(getClass(), "/" + fn);
			m = MediaManager.createMedia(input, "audio/wav", this);
		}
		catch(Exception event) {
			event.printStackTrace();
		}
	}
	
	/**
	 * Play.
	 */
	public void play() {
		m.play();
		m.setVolume(8);
		
	}
	
	/**
	 * Pause.
	 */
	public void pause() {
		m.pause();
	}

}
