package com.mycompany.a3;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Button;
import com.codename1.ui.Command;
import com.codename1.ui.Component;

public class ButtonStyles extends Button {
	public ButtonStyles(Command cmd) {
		this.getAllStyles().setBgTransparency(255);
		this.getAllStyles().setBgColor(ColorUtil.BLUE);
		this.getAllStyles().setFgColor(ColorUtil.WHITE);
		this.getAllStyles().setPadding(Component.TOP, 5);
		this.getAllStyles().setPadding(Component.BOTTOM, 5);
		this.getAllStyles().setMargin(Component.LEFT, 15);
		this.getAllStyles().setMargin(Component.RIGHT, 15);
		this.getAllStyles().setMargin(Component.TOP, 15);
		this.getAllStyles().setMargin(Component.BOTTOM, 15);
	}

}
