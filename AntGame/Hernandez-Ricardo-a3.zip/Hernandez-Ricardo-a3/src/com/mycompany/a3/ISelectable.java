package com.mycompany.a3;

import com.codename1.ui.geom.Point;
import com.codename1.ui.Graphics; 

/**
 * The Interface ISelectable.
 */
public interface ISelectable {
	
	/**
	 * Sets the selected.
	 *
	 * @param b the new selected
	 */
	//lecture notes 10
	public void setSelected(boolean b);
	
	/**
	 * Checks if is selected.
	 *
	 * @return true, if is selected
	 */
	public boolean isSelected();
	
	/**
	 * Contains.
	 *
	 * @param pPtrRelPrnt the ptr rel prnt
	 * @param pCmpRelPrnt the cmp rel prnt
	 * @return true, if successful
	 */
	public boolean contains(Point pPtrRelPrnt, Point pCmpRelPrnt);
		
	/**
	 * Draw.
	 *
	 * @param g the g
	 * @param pCmpRelPrnt the cmp rel prnt
	 */
	public void draw(Graphics g, Point pCmpRelPrnt);
}
