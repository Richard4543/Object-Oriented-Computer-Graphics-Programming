package com.mycompany.a3;

import com.codename1.ui.Component;
import com.codename1.ui.Container;
import com.codename1.ui.Label;
import com.codename1.ui.layouts.FlowLayout;

import java.util.Observable;
import java.util.Observer;

/**
 * The Class ScoreView.
 */
public class ScoreView extends Container implements Observer {
	
	/** The Clock. */
	private Label Clock;
	
	/** The lives left. */
	private Label livesLeft;
	
	/** The last flag reached. */
	private Label lastFlagReached;
	
	/** The ant food level. */
	private Label antFoodLevel;
	
	/** The ant health. */
	private Label antHealth;
	
	private Label Sound;

	
	/**
	 * Instantiates a new score view.
	 */
	public ScoreView() {
		
		this.setLayout(new FlowLayout(CENTER));
		
		this.Sound = new Label("Sound: ");
		this.addComponent(Sound);
		
		this.Clock = new Label("Time: ");
		this.addComponent(Clock);
		this.Clock.getUnselectedStyle().setBgColor(255);
		this.Clock.getAllStyles().setPadding(Component.RIGHT, 10);
		
		this.livesLeft = new Label("Lives: ");
		this.addComponent(livesLeft);
		this.livesLeft.getUnselectedStyle().setBgColor(255);
		this.livesLeft.getAllStyles().setPadding(Component.RIGHT, 10);
		
		this.lastFlagReached = new Label("Last Flag: ");
		this.addComponent(lastFlagReached);
		this.lastFlagReached.getUnselectedStyle().setBgColor(255);
		this.lastFlagReached.getAllStyles().setPadding(Component.RIGHT, 10);
		
		this.antFoodLevel = new Label("Food: ");
		this.addComponent(antFoodLevel);
		this.antFoodLevel.getUnselectedStyle().setBgColor(255);
		this.antFoodLevel.getAllStyles().setPadding(Component.RIGHT, 10);
		
		this.antHealth = new Label("Health: ");
		this.addComponent(antHealth);
		this.antHealth.getUnselectedStyle().setBgColor(255);
		this.antHealth.getAllStyles().setPadding(Component.RIGHT, 10);
	}


	/* (non-Javadoc)
	 * @see java.util.Observer#update(java.util.Observable, java.lang.Object)
	 */
	@Override
	public void update(Observable observable, Object data) {
		Ant ant = Ant.getAnt();
		GameWorld gw = (GameWorld) observable;
		
		if(gw.gettoggleSound()) {
			Sound.setText("Sound: On");
		}
		else {
			Sound.setText("Sound: Off");
		}
		Clock.setText("Time: " + gw.getClock());
		livesLeft.setText("Lives: " + gw.getLives());
		lastFlagReached.setText("Last Flag: " + ant.getLastFlagReached());
		antFoodLevel.setText("Food Level: " + ant.getFoodLevel());
		antHealth.setText("Health: " + ant.getHealthLevel());
		
	}

}
