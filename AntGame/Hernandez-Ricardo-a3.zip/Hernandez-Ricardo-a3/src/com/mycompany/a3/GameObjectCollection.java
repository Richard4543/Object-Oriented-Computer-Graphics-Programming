package com.mycompany.a3;

import java.util.Vector;

public class GameObjectCollection implements ICollection {
	
	private Vector<GameObject> gameObjects;
	
	public GameObjectCollection(){
		this.gameObjects = new Vector<GameObject>();
	}

	@Override
	public void add(GameObject Object) {
		this.gameObjects.addElement(Object);
	}

	@Override
	public IIterator getIterator() {
		return new GameObjectIterator();
	}

	@Override
	public void remove(GameObject Object) {
		this.gameObjects.removeElement(Object);
		
	}
	
	private class GameObjectIterator implements IIterator{
		
		private int currentObjectIndex;

		@Override
		public boolean hasNext() {
			if(gameObjects.size() < 1) {
				return false;
			}
			if(currentObjectIndex == gameObjects.size() - 1) {
				return false;
			}
			
			return true;
		}

		@Override
		public Object getNext() {
			currentObjectIndex++;
			return(gameObjects.elementAt(currentObjectIndex));
		}
		
		public GameObjectIterator() {
			
			currentObjectIndex = -1;
		}
		
	}
	
	public void clear() {
		this.gameObjects.clear();
	}

}
