package com.mycompany.a3;

import com.codename1.ui.Form;
import com.codename1.ui.Toolbar;
import com.codename1.ui.layouts.BorderLayout;
import com.codename1.ui.layouts.BoxLayout;
import com.codename1.ui.layouts.FlowLayout;
import com.codename1.ui.plaf.Border;
import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.CheckBox;
import com.codename1.ui.Component;
import com.codename1.ui.Container;
import com.codename1.ui.Button;
import com.codename1.ui.geom.Dimension;
import com.codename1.ui.util.UITimer;

/**
 * The Class Game.
 *
 * @author Ricardo Hernandez
 * The Class Game.
 */
public class Game extends Form implements Runnable {

	/** The exit. */
	//private boolean exit = false;

	/** The gw. */
	private GameWorld gw;

	/** The sv. */
	private ScoreView sv;

	/** The mv. */
	private MapView mv;

	/** The accelerate button. */
	private Button accelerateButton;
	
	/** The brake button. */
	private Button brakeButton;
	
	/** The right button. */
	private Button rightButton;
	
	/** The left button. */
	private Button leftButton;
	
	/** The pause button. */
	private Button pauseButton;
	
	/** The position button. */
	private Button positionButton;
	
	/** The pause. */
	private boolean pause; //might set to false

	/** The accelerate command. */
	private AccelerateCommand accelerateCommand;
	
	/** The brake command. */
	private BrakeCommand brakeCommand;
	
	/** The right command. */
	private RightCommand rightCommand;
	
	/** The left command. */
	private LeftCommand leftCommand;
	
	/** The pause command. */
	private PauseCommand pauseCommand;
	
	/** The position command. */
	private PositionCommand positionCommand;
	
	/** The timer. */
	private UITimer timer;
	



	/**
	 * Instantiates a new game.
	 */
	public Game() {
		gw = new GameWorld();
		mv = new MapView(this);
		sv = new ScoreView();
		

		gw.addObserver(mv);
		gw.addObserver(sv);
		this.setLayout(new BorderLayout());

		this.accelerateButton = new Button("Accelerate");
		this.accelerateCommand = new AccelerateCommand(this.gw);
		this.brakeButton = new Button("break");
		this.brakeCommand = new BrakeCommand(this.gw);
		this.rightButton = new Button("right");
		this.rightCommand = new RightCommand(this.gw);
		this.leftButton = new Button("left");
		this.leftCommand = new LeftCommand(this.gw);
		this.pause = false;
		this.pauseButton = new Button("Pause");
		this.pauseCommand = new PauseCommand(this);
		this.positionButton = new Button("Pause");
		this.positionCommand = new PositionCommand(this, this.mv);


		gw.init();

		add(BorderLayout.NORTH,sv);
		/*AccelerateCommand*/ accelerateCommand = new AccelerateCommand(this.gw);
		setToolbar(accelerateCommand);

		add(BorderLayout.CENTER,mv);
		setLeftContainer();
		setRightContainer();
		setBottomContainer();

		gw.notifyObservers(gw.getCollection());
		this.show();

		gw.setWidth(mv.getWidth());
		gw.setHeight(mv.getHeight());
		
		gw.createSounds();
		revalidate();
		
		timer = new UITimer(this);

		play();

	}

	/**
	 * Checks if is paused.
	 *
	 * @return true, if is paused
	 */
	public boolean isPaused() {
		return pause;
	}

	/**
	 * Sets the paused.
	 *
	 * @param pause the new paused
	 */
	public void setPaused(boolean pause) {
		this.pause = pause;
	}
	

	/**
	 * Sets the toolbar.
	 *
	 * @param accelerateCommand the new toolbar
	 */
	private void setToolbar(AccelerateCommand accelerateCommand) {
		Toolbar myToolbar = new Toolbar();
		setToolbar(myToolbar);		
		myToolbar.setTitle("The Ant");
		myToolbar.getAllStyles().setBgColor(ColorUtil.BLUE);


		CheckBox soundOn = new CheckBox("Sound");
		soundOn.getAllStyles().setBgTransparency(255);
		soundOn.getAllStyles().setBgColor(ColorUtil.GRAY);
		SoundCommand soundCommand = new SoundCommand(this.gw, soundOn);
		soundOn.setCommand(soundCommand);
		myToolbar.addComponentToSideMenu(soundOn);

		myToolbar.addCommandToSideMenu(accelerateCommand);


		AboutCommand aboutCommand = new AboutCommand();
		myToolbar.addCommandToSideMenu(aboutCommand);


		ExitCommand exitCommand = new ExitCommand();
		myToolbar.addCommandToSideMenu(exitCommand);

		HelpCommand helpCommand = new HelpCommand();
		myToolbar.addCommandToRightBar(helpCommand);


	}


	/**
	 * Sets the botom container.
	 */
	private void setBottomContainer() {
		Container bottomContainer = new Container(new FlowLayout(Component.CENTER));

		positionButton = new ButtonStyles(positionCommand);
		positionButton.setCommand(positionCommand);
		bottomContainer.add(positionButton);
		
		pauseButton = new ButtonStyles(pauseCommand);
		pauseButton.setCommand(pauseCommand);
		bottomContainer.add(pauseButton);
		
		

		bottomContainer.getAllStyles().setBorder(Border.createLineBorder(2,ColorUtil.BLACK));

		add(BorderLayout.SOUTH, bottomContainer);

	}

	/**
	 * Sets the left container.
	 */
	public void setLeftContainer() {

		//AccelerateCommand accelerateCommand = new AccelerateCommand(this.gw);
		Container leftContainer = new Container(new BoxLayout(BoxLayout.Y_AXIS));

		//AccelerateCommand commandAccelerate = new AccelerateCommand(this.gw);
		 accelerateButton = new ButtonStyles(accelerateCommand);

		accelerateButton.setCommand(accelerateCommand);
		//addKeyListener('a', accelerateCommand);
		leftContainer.add(accelerateButton);

		//LeftCommand commandLeft = new LeftCommand(this.gw);
		 leftButton = new ButtonStyles(leftCommand);
		leftButton.setCommand(leftCommand);
		//addKeyListener('l', commandLeft);
		leftContainer.add(leftButton);

		leftContainer.getAllStyles().setPadding(Component.TOP, 50);
		leftContainer.getAllStyles().setBorder(Border.createLineBorder(4,ColorUtil.BLACK));

		add(BorderLayout.WEST, leftContainer);

	}

	/**
	 * Sets the right container.
	 */
	public void setRightContainer() {
		Container rightContainer = new Container(new BoxLayout(BoxLayout.Y_AXIS));

		//BrakeCommand commandBrake = new BrakeCommand(this.gw);
		 brakeButton = new ButtonStyles(brakeCommand);
		brakeButton.setCommand(brakeCommand);
		//addKeyListener('b', commandBrake);
		rightContainer.add(brakeButton);


		//RightCommand commandRight = new RightCommand(this.gw);
		 rightButton = new ButtonStyles(rightCommand);
		rightButton.setCommand(rightCommand);
		//6addKeyListener('r', commandRight);
		rightContainer.add(rightButton);

		rightContainer.getAllStyles().setPadding(Component.TOP, 50);
		rightContainer.getAllStyles().setBorder(Border.createLineBorder(4,ColorUtil.BLACK));

		add(BorderLayout.EAST, rightContainer);

	}

	/**
	 * Play.
	 */
	public void play() {
		
		if(gw.gettoggleSound()) {
			gw.getBackGroundSound().play();
		}
		
		pauseButton.setText("Pause");
		this.setPaused(false);
		positionButton.getDisabledStyle();
		
		addKeyListener('a', accelerateCommand);
		addKeyListener('b', brakeCommand);
		addKeyListener('r', rightCommand);
		addKeyListener('l', leftCommand);
		

		accelerateButton.setEnabled(true);
		brakeButton.setEnabled(true);
		rightButton.setEnabled(true);
		leftButton.setEnabled(true);
		
		positionButton.setEnabled(false);
		//positionCommand.setEnabled(false);
		
		timer.schedule(600, true, this);
	}
	
	/**
	 * Pause game.
	 */
	public void pauseGame() {
		timer.cancel();
		gw.getBackGroundSound().pause();
		
		removeKeyListener('a', accelerateCommand);
		removeKeyListener('b', brakeCommand);
		removeKeyListener('l', leftCommand);
		removeKeyListener('r', rightCommand);
		addKeyListener('o', positionCommand);
		
		accelerateButton.setEnabled(false);
		brakeButton.setEnabled(false);
		rightButton.setEnabled(false);
		leftButton.setEnabled(false);
		
		positionButton.setEnabled(true);
		//positionCommand.setEnabled(true);
		
		pauseButton.setText("Play ");
		this.setPaused(true);
		
	}

	/* (non-Javadoc)
	 * @see java.lang.Runnable#run()
	 */
	@Override
	public void run() {
		Dimension dCmpSize = new Dimension(mv.getWidth(), mv.getHeight());

		gw.Clock(2000, dCmpSize);		//remove 10000
		gw.notifyObservers();
	}
}
