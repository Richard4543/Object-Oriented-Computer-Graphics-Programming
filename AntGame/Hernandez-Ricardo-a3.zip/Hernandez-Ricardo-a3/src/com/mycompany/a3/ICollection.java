package com.mycompany.a3;

/**
 * The Interface ICollection.
 */
public interface ICollection {


		/**
		 * Adds the.
		 *
		 * @param Object the obj
		 */
		public void add(GameObject Object);
		

		/**
		 * Gets the iterator.
		 *
		 * @return the iterator
		 */
		public IIterator getIterator();

		/**
		 * Removes the.
		 *
		 * @param Object the obj
		 */
		public void remove(GameObject Object);
}
