package com.mycompany.a3;

import com.codename1.charts.models.Point;
import com.codename1.charts.util.ColorUtil;
import java.util.Vector;
/**
 * The Class GameObject.
 *
 * @author Ricardo Hernandez
 * The Class GameObject.
 * @author Ricardo Hernandez
 */
public abstract class GameObject implements IDrawable, ICollider {

	/** The size. */
	private int size;

	/** The color. */
	private int color;

	/** The location. */
	private Point location;

	/** The x. */
	private float x;

	/** The y. */
	private float y;
	
	private Vector<GameObject> ObjectList = new Vector<GameObject>();
	
	//private Vector<GameObject> ObjectList;

	/* (non-Javadoc)
	 * @see com.mycompany.a3.ICollider#collidesWith(com.mycompany.a3.GameObject)
	 */
	public abstract boolean collidesWith(GameObject anotherObject);

	/* (non-Javadoc)
	 * @see com.mycompany.a3.ICollider#handleCollision(com.mycompany.a3.GameObject, com.mycompany.a3.GameWorld)
	 */
	public abstract void handleCollision(GameObject anotherObject, GameWorld gw);

	/**
	 * Instantiates a new game object.
	 */
	public GameObject() {
		this.size = 0;
		this.location = new Point();
		this.color = ColorUtil.rgb(255, 200, 0);
		//lists
		//ObjectList = new Vector<GameObject>();
	}

	/**
	 * Instantiates a new game object.
	 *
	 * @param size the size
	 * @param x the x
	 * @param y the y
	 * @param color the color
	 */
	public GameObject(int size, float x, float y, int color) {
		this.size = size;
		this.color = color;
		this.location = new Point(x, y);
	}
	//lists
	public void add(GameObject newObject) {
		ObjectList.add(newObject);
	}
	//lists
	public void remove(GameObject newObj) {
		// TODO Auto-generated method stub
		ObjectList.remove(newObj);
	}
	
	public void clear() {
		this.ObjectList.clear();
	}
	
	public Vector<GameObject> returnList() {
		return ObjectList;
	}
	/**
	 * Gets the size.
	 *
	 * @return the size
	 */
	public int getSize() {
		return this.size;
	}

	/**
	 * Gets the x.
	 *
	 * @return the x
	 */
	public float getX() {
		return x;
	}

	/**
	 * Gets the y.
	 *
	 * @return the y
	 */
	public float getY() {
		return y;
	}

	/**
	 * Gets the color.
	 *
	 * @return the color
	 */
	public int getColor() {
		return this.color;
	}

	/**
	 * Gets the location.
	 *
	 * @return the location
	 */
	public Point getLocation() {
		return this.location;
	}

	/**
	 * Sets the size.
	 *
	 * @param size the new size
	 */
	public void setSize(int size) {
		this.size = size;
	}

	/**
	 * Sets the color.
	 *
	 * @param r the r
	 * @param g the g
	 * @param b the b
	 */
	public void setColor(int r, int g, int b) {
		this.color = ColorUtil.rgb(r,  g,  b);
	}

	/**
	 * Sets the location.
	 *
	 * @param x the x
	 * @param y the y
	 */
	public void setLocation(float x, float y) {
		this.location = new Point(x, y);
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	/* toString
	 * @Overide
	 */
	public String toString() {
		String parent = " Location: " + location.getX() + " / " + location.getY() + " Color: " + ColorUtil.red(this.color) + ", "  + ColorUtil.green(this.color) + ", "  + ColorUtil.blue(this.color);
		return parent;
	}
}
