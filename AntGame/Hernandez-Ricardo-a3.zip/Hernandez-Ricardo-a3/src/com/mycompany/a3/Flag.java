package com.mycompany.a3;

import com.codename1.ui.geom.Point;
import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Graphics;


/**
 * The Class Flag.
 *
 * @author Ricardo Hernandez
 * The Class Flag.
 */
public class Flag extends Fixed {

	/** The select. */
	private boolean select;

	/** The sequence number. */
	private int sequenceNumber;

	/**
	 * Instantiates a new flag.
	 *
	 * @param size the size
	 * @param locationX the location X
	 * @param locationY the location Y
	 * @param sequenceNumber the sequence number
	 */
	public Flag(int size, float locationX, float locationY, int sequenceNumber) {
		super(size, locationX, locationY, ColorUtil.rgb(0, 0, 255));
		this.sequenceNumber = sequenceNumber; //Sequence number for flags 1-4
		this.select = false;
	}


	/* (non-Javadoc)
	 * @see com.mycompany.a3.IDrawable#draw(com.codename1.ui.Graphics, com.codename1.ui.geom.Point)
	 */
	@Override
	public void draw(Graphics g, Point pCmpRelPrnt) {
		g.setColor(super.getColor());
		int locx = (int) getLocation().getX() + pCmpRelPrnt.getX();
		int locy = (int) getLocation().getY() + pCmpRelPrnt.getY();
		int[] xArray = {locx, (locx - getSize()), (locx + getSize()), locx};
		int[] yArray = {(locy + getSize()), (locy - getSize()), (locy - getSize()), (locy + getSize())};

		int nPoints = 4;
		g.setAlpha(100);
		g.drawString(Integer.toString(getSequenceNumber()), locx - getSize() / 5, (int) ((int) locy - getSize() / 1.82));
		if(!isSelected()) {
			g.drawPolygon(xArray, yArray, nPoints);
			g.fillPolygon(xArray, yArray, nPoints);
		}else {
			g.fillPolygon(xArray, yArray, nPoints);
			//g.fillPolygon(xArray, yArray, nPoints);
		}

		g.setAlpha(255);
	}

	/* (non-Javadoc)
	 * @see com.mycompany.a3.GameObject#collidesWith(com.mycompany.a3.GameObject)
	 */
	@Override
	public boolean collidesWith(GameObject anotherObject) {
		boolean res = false;
		int x1 = (int) getLocation().getX();
		int y1 = (int) getLocation().getY();
		int x2 = (int) anotherObject.getLocation().getX();
		int y2 = (int) anotherObject.getLocation().getY();

		int radius1 = this.getSize() / 2;
		int radius2 = this.getSize() / 2;
		int distanceX = x1 - x2;
		int distanceY = y1 - y2;

		int centerDistance = ((distanceX * distanceX) + (distanceY * distanceY));
		int radSqr = ((radius1 * radius1) + (2 * radius1 * radius2) + (radius2 * radius2));

		if(centerDistance <= radSqr) {
			res = true;
		}
		return res;
	}

	/* (non-Javadoc)
	 * @see com.mycompany.a3.GameObject#handleCollision(com.mycompany.a3.GameObject, com.mycompany.a3.GameWorld)
	 */
	@Override
	public void handleCollision(GameObject anotherObject, GameWorld gw) {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see com.mycompany.a3.ISelectable#setSelected(boolean)
	 */
	//override
	public void setSelected(boolean b) {
		this.select = b;
	}

	/* (non-Javadoc)
	 * @see com.mycompany.a3.ISelectable#isSelected()
	 */
	//override
	public boolean isSelected() {
		return select;
	}

	/* (non-Javadoc)
	 * @see com.mycompany.a3.ISelectable#contains(com.codename1.ui.geom.Point, com.codename1.ui.geom.Point)
	 */
	@Override
	public boolean contains(Point pPtrRelPrnt, Point pCmpRelPrnt) {
		// TODO Auto-generated method stub
		int px = pPtrRelPrnt.getX();
		int py = pPtrRelPrnt.getY();
		int locx = pCmpRelPrnt.getX() + (int) getLocation().getX();
		int locy = pCmpRelPrnt.getY() + (int) getLocation().getY();
		if((px >= locx - getSize() / 2) && (px <= locx + getSize() / 2) && (py >= locy - getSize() / 2) && (py <= locy + getSize() / 2)) {
			return true;
		}else {
			return false;
		}
	}
	/**
	 * Gets the sequence number.
	 *
	 * @return the sequence number
	 */
	public int getSequenceNumber() {
		return sequenceNumber;
	}

	/**
	 * Sets the sequence number.
	 *
	 * @param sequenceNumber the new sequence number
	 */
	public void setSequenceNumber(int sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}


	/* (non-Javadoc)
	 * @see com.mycompany.a3.GameObject#setColor(int, int, int)
	 */
	/*
	 * Sets the color
	 * @param r, g, b 
	 */
	public void setColor(int r, int g, int b) {

	}

	/* (non-Javadoc)
	 * @see com.mycompany.a3.Fixed#toString()
	 */
	/* toString
	 * @Overide
	 */
	public String toString() {
		String parentDesc = super.toString();
		String myDesc = " sequenceNumber: " + this.getSequenceNumber();
		return parentDesc + myDesc;
	}
}
