package com.mycompany.a3;

import com.codename1.ui.events.ActionEvent;
import com.codename1.ui.Command;
import com.codename1.ui.Dialog;

/**
 * The Class AboutCommand.
 */
public class AboutCommand extends Command{
	
	/**
	 * Instantiates a new about command.
	 */
	public AboutCommand() {
		super("About");
	}
	
	/* (non-Javadoc)
	 * @see com.codename1.ui.Command#actionPerformed(com.codename1.ui.events.ActionEvent)
	 */
	public void actionPerformed(ActionEvent Events) {
		String aboutText = (""
		        + "\n" + "Name: Ricardo Hernandez"
		        + "\n" + "CSC 133"
		        + "\n" + "Title: Ant Game");
		Command okayButton = new Command("Ok");
		
		Dialog.show("About",  aboutText, okayButton);
	}
}
