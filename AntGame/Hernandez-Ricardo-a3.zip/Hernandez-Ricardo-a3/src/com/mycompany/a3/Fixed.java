package com.mycompany.a3;
import com.codename1.charts.models.Point;
import com.codename1.charts.util.ColorUtil;

/**@author Ricardo Hernandez
 * The Class Fixed.
 */
public abstract class Fixed extends GameObject implements ISelectable{
	
	/** The size. */
	private int size;				//may not need
	
	/** The x. */
	private float x;				//may not need
	
	/** The y. */	
	private float y;				//may not need
	
	/** The color. */
	private int color;				//may not need
	
	/** The location. */
	private Point location;			//may not need
	
	
	/**
	 * Instantiates a new fixed.
	 *
	 * @param size the size
	 * @param locationX the location X
	 * @param locationY the location Y
	 * @param color the color
	 */
	public Fixed(int size, float locationX, float locationY, int color) {
		super(size, locationX, locationY, color);
	}
	
	//add toString to get the size of all fixed objects
	//pull toString
	
	/**toString
	 * @return
	 * @Overide
	 */
	public String toString() {
		String parent = super.toString();		//super toString from gameobjects
		String Objects = " Size: " + super.getSize(); // grabs size from gameObject
		return parent + Objects;
	}
	
}
