package com.mycompany.a3;

import com.codename1.ui.Command;
import com.codename1.ui.events.ActionEvent;

/**
 * The Class AccelerateCommand.
 */
public class AccelerateCommand extends Command {

	/** The gw. */
	private GameWorld gw;
	
	/**
	 * Instantiates a new accelerate command.
	 *
	 * @param gw the gw
	 */
	public AccelerateCommand(GameWorld gw) {
		super("Accelerate");
		this.gw = gw;
	}
	
	/* (non-Javadoc)
	 * @see com.codename1.ui.Command#actionPerformed(com.codename1.ui.events.ActionEvent)
	 */
	@Override
	public void actionPerformed(ActionEvent Events){
		gw.accelerate();
		
		
	}
}
