package com.mycompany.a3;

/**@author Ricardo Hernandez
 * The Class Moveable.
 */
public abstract class Moveable extends GameObject {
	
	/** The speed. */
	private int speed;
	
	/** The heading. */
	private int heading;
	
	
	/**
	 * Instantiates a new moveable.
	 *
	 * @param heading the heading
	 * @param speed the speed
	 * @param size the size
	 * @param locationX the location X
	 * @param locationY the location Y
	 * @param color the color
	 */
	public Moveable(int heading, int speed, int size, float locationX, float locationY, int color) {
		super(size, locationX, locationY, color);
		this.heading = heading;
		this.speed = speed;
	}
	
	/**
	 * Move.
	 */
	public abstract void Move(double width, double height, double time);
	
	
	/**
	 * Gets the heading.
	 *
	 * @return the heading
	 */
	public int getHeading(){
		return heading;
	}
	
	/**
	 * Gets the speed.
	 *
	 * @return the speed
	 */
	public int getSpeed() {
		return speed;
	}
	
	/**
	 * Sets the heading.
	 *
	 * @param heading the new heading
	 */
	public void setHeading(int heading) {
		this.heading = heading;
	}
	
	/**
	 * Sets the speed.
	 *
	 * @param speed the new speed
	 */
	public void setSpeed(int speed) {
		this.speed = speed;
	}
	
	/* toString
	 * @sOveride
	 */
	public String toString() {
		String parentDesc = super.toString();
		String myDesc = 
				" Heading: " + this.heading + " Speed: " + this.speed + " Size: " + super.getSize();
		return parentDesc + myDesc;
	}
}
