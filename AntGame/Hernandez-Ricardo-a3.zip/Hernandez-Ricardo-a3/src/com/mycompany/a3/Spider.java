package com.mycompany.a3;

import java.util.Random;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Graphics;
import com.codename1.ui.geom.Point;


/**
 * The Class Spider.
 *
 * @author Ricardo Hernandez
 * The Class Spider.
 */
public class Spider extends Moveable {

	/**
	 * Instantiates a new spider.
	 */
	//from FoodStations class, may need changing
	public Spider() {
		super(getRandomInt(360, 0), getRandomInt(15, 5),getRandomInt(35, 15), getRandomFloat((float)1000.0, (float)0.0),getRandomFloat((float)1000.0, (float)0.0), ColorUtil.rgb(0, 0, 0));
	}

	/**
	 * Instantiates a new spider.
	 *
	 * @param locationX the location X
	 * @param locationY the location Y
	 */
	public Spider(float locationX, float locationY) {
		super(getRandomInt(360, 0), getRandomInt(15, 5),getRandomInt(35, 15), locationX, locationY, ColorUtil.rgb(0, 0, 0));
	}

	/**
	 * Gets the random int.
	 *
	 * @param max the max
	 * @param min the min
	 * @return the random int
	 */
	public static int getRandomInt(int max, int min) {
		Random rand = new Random();
		return min + rand.nextInt(max - min);
	}

	/**
	 * Gets the random float.
	 *
	 * @param max the max
	 * @param min the min
	 * @return the random float
	 */
	public static float getRandomFloat(float max, float min) {
		Random rand = new Random();
		float a = min+ (max - min) * rand.nextFloat();
		return (float)(Math.round(a * 10.0) / 10.0);
	}

	/* (non-Javadoc)
	 * @see com.mycompany.a3.Moveable#Move(double, double, double)
	 */
	/* 
	 * Move for Spider
	 */
	public void Move(double width, double height, double time) {
		double distance = (super.getSpeed() * time) / 1000;
		//double max = 1000.0;
		double min = 0.0;
		double theta = Math.toRadians(90 - super.getHeading());
		double deltaX = (double) (Math.cos(Math.toRadians(theta)) * distance) + super.getLocation().getX(); 
		double deltaY = (double) (Math.sin(Math.toRadians(theta)) * distance) + super.getLocation().getY();

		if (deltaX < min || deltaX > width || deltaY < min || deltaY > height) {			//Checks if in bounds, else change heading
			super.setHeading((int) (super.getHeading() + Math.toDegrees(180)));
			
		}
		super.setLocation((float) deltaX, (float) deltaY);
		super.setHeading((int) (super.getHeading() + Math.toDegrees(getRandomInt(25, -25))));
	}

	/* (non-Javadoc)
	 * @see com.mycompany.a3.Moveable#toString()
	 */
	/* toString
	 * 
	 */
	@Override
	public String toString() {
		return super.toString();
	}

	/* (non-Javadoc)
	 * @see com.mycompany.a3.IDrawable#draw(com.codename1.ui.Graphics, com.codename1.ui.geom.Point)
	 */
	@Override
	public void draw(Graphics g, Point pCmpRelPrnt) {
		g.setColor(getColor());
		int lox = (int) (pCmpRelPrnt.getX() + getLocation().getX() - (getSize() / 2));
		int loy = (int) (pCmpRelPrnt.getY() + getLocation().getY() - (getSize() / 2));
		int[] xArray = {lox, (lox - getSize()), (lox + getSize()), lox};
		int[] yArray = {(loy + getSize()), (loy - getSize()), (loy - getSize()), (loy + getSize())};

		int nPoints = 4;
		//g.fillTriangle(lox - 20, loy, lox, loy + 30, lox + 20, loy);
		//g.clearRect(lox, loy, getSize(), getSize());
		g.drawPolygon(xArray, yArray, nPoints);
		//g.fillPolygon(xArray, yArray, nPoints);	

	}

	/* (non-Javadoc)
	 * @see com.mycompany.a3.GameObject#collidesWith(com.mycompany.a3.GameObject)
	 */
	@Override
	public boolean collidesWith(GameObject anotherObject) {
		boolean res = false;
		int x1 = (int) getLocation().getX();
		int y1 = (int) getLocation().getY();
		int x2 = (int) anotherObject.getLocation().getX();
		int y2 = (int) anotherObject.getLocation().getY();

		int radius1 = this.getSize() / 2;
		int radius2 = this.getSize() / 2;
		int distanceX = x1 - x2;
		int distanceY = y1 - y2;

		int centerDistance = ((distanceX * distanceX) + (distanceY * distanceY));
		int radSqr = ((radius1 * radius1) + (2 * radius1 * radius2) + (radius2 * radius2));

		if(centerDistance <= radSqr) {
			res = true;
		}
		return res;
	}

	/* (non-Javadoc)
	 * @see com.mycompany.a3.GameObject#handleCollision(com.mycompany.a3.GameObject, com.mycompany.a3.GameWorld)
	 */
	@Override
	public void handleCollision(GameObject anotherObject, GameWorld gw) {
		// TODO Auto-generated method stub

	}
}


