package com.mycompany.a3;

import java.util.Observable;
import com.codename1.ui.geom.Dimension;

/**
 * The Class GameWorld.
 *
 * @author Ricardo Hernandez
 * The Class GameWorld.
 */
public class GameWorld extends Observable {

	/** The clock. */
	private int clock;

	/** The lives. */
	private int lives;

	/** The ant. */
	private static Ant ant;

	/** The game objects. */
	private GameObjectCollection gameObjects;

	/** The width. */
	private double width;

	/** The height. */
	private double height;

	/** The sound on. */
	private boolean soundOn;		//or false
	
	/** The bg sound. */
	private BGSound bgSound;
	
	/** The spider collide. */
	//new sound
	private Sound spiderCollideSound;
	
	private Sound stepSound;
	
	private Sound coinSound;
	
	private Sound biteSound;

	/**
	 * Instantiates a new game world.
	 */
	public GameWorld() {
		this.lives = 3;
		this.clock = 0;
		this.gameObjects = new GameObjectCollection();			//may or may not use ArrayList, will decide later
		width = 0;
		height = 0;
	}

	/**
	 * Inits the.
	 */
	public void init() {
		//sounds
		
		
		
		Flag flagOne = new Flag(10, (float)100.0, (float) 200.0, 1);
		Flag flagTwo = new Flag(10, (float)100.0, (float) 800.0, 2);
		Flag flagThree = new Flag(10, (float)800.0, (float) 800.0, 3);
		Flag flagFour = new Flag(10, (float)800.0, (float) 400.0, 4);

		float antLocX = flagOne.getLocation().getX();
		float antLocY = flagOne.getLocation().getY();

		ant = ant.getAnt();
		ant.setLocation(antLocX, antLocY);

		Spider spiderOne = new Spider();
		Spider spiderTwo = new Spider();
		FoodStations stationOne = new FoodStations();
		FoodStations stationTwo = new FoodStations();

		gameObjects.add(flagOne);
		gameObjects.add(flagTwo);
		gameObjects.add(flagThree);
		gameObjects.add(flagFour);

		gameObjects.add(ant);
		gameObjects.add(spiderOne);
		gameObjects.add(spiderTwo);

		gameObjects.add(stationOne);
		gameObjects.add(stationTwo);

		this.setChanged();
	}
	
	/**
	 * Creates the sounds.
	 */
	//new sound
	public void createSounds() {
		setBackGroundSound(new BGSound("bensound-littleidea.wav"));
		spiderCollideSound = new Sound("squeak.wav");
		coinSound = new Sound("oneUp.wav");
		biteSound = new Sound("hb17.wav");
		stepSound = new Sound("step16.wav");
	}

	/**
	 * Gets the clock.
	 *
	 * @return the clock
	 */
	public int getClock() {
		return clock;
	}

	/**
	 * Gets the lives.
	 *
	 * @return the lives
	 */
	public int getLives() {
		return lives;
	}

	/**
	 * Sets the lives.
	 *
	 * @param lives the new lives
	 */
	public void setLives(int lives) {
		this.lives = lives;
	}

	/**
	 * Sets the clock.
	 *
	 * @param clock the new clock
	 */
	public void setClock(int clock) {
		this.clock = clock;
	}

	/**
	 * Accelerate.
	 */
	public void accelerate() {
		ant.speedIncrease();
		this.setChanged();
		notifyObservers();	//notifyObservers(getCollection());
	}

	/**
	 * Brake.
	 */
	public void brake() {
		ant.speedDecrease();
		this.setChanged();
		notifyObservers();
	}


	/**
	 * Gets the collection.
	 *
	 * @return the collection
	 */
	public GameObjectCollection getCollection() {
		return this.gameObjects;
	}

	/**
	 * Sets the height.
	 *
	 * @param height the new height
	 */
	public void setHeight(double height) {
		this.height = height;
	}

	/**
	 * Sets the width.
	 *
	 * @param width the new width
	 */
	public void setWidth(double width) {
		this.width = width;
	}
	

	/**
	 * Change heading.
	 *
	 * @param direction the direction
	 */
	public void changeHeading(char direction) {
		ant.changeHeading(direction);
		System.out.println("Heading changed: " + direction);
		
		this.setChanged();
		notifyObservers();
	}
	
	/**
	 * Gets the back ground sound.
	 *
	 * @return the back ground sound
	 */
	public BGSound getBackGroundSound() {
		return bgSound;
	}
	
	/**
	 * Sets the back ground sound.
	 *
	 * @param bgSound the new back ground sound
	 */
	public void setBackGroundSound(BGSound bgSound) {
		this.bgSound = bgSound;
	}

	/**
	 * Toggle sound.
	 *
	 * @return true, if successful
	 */
	public boolean gettoggleSound() {
		return soundOn;
	}

	/**
	 * Toggle sound.
	 *
	 * @param soundOn the sound on
	 */
	public void toggleSound(boolean soundOn) {
		this.soundOn = soundOn; 
		if(soundOn) {
			getBackGroundSound().play();
		}
		else {
			getBackGroundSound().pause();
		}
		
		this.setChanged();
		notifyObservers();
	}


	/**
	 * Check collision.
	 */
	public void checkCollision() {
		IIterator iterator = gameObjects.getIterator();
		while(iterator.hasNext()) {
			GameObject currentObject = (GameObject) iterator.getNext();
			IIterator secondIterator = gameObjects.getIterator();
			while(secondIterator.hasNext()) {
				GameObject anotherObject =  (GameObject) secondIterator.getNext();
				if(anotherObject != currentObject && !currentObject.returnList().contains(anotherObject)) {		//and not in list

					if(currentObject.collidesWith((GameObject) anotherObject)){

						currentObject.handleCollision((GameObject) anotherObject, this);
						currentObject.add(anotherObject);
					}
				}
			}
		}
	}

	/**
	 * Clock.
	 *
	 * @param time the time
	 * @param dCmpSize the d cmp size
	 */


	public void Clock(int time, Dimension dCmpSize) {
		/*Ant ant = Ant.getAnt();
		ant.Move(this.width, this.height);
		ant.setFoodLevel(ant.getFoodLevel() - ant.getFoodConsumptionRate());//food level reduced
		IIterator objects = gameObjects.getIterator();
		while(objects.hasNext()) {
			GameObject Object = (GameObject) objects.getNext();
			if(Object instanceof Spider) {
				Spider spider = (Spider) Object;
				spider.Move(this.width, this.height);
			}
		}
		this.setClock(clock + 1);
		this.Lives();	
		this.setChanged();
		notifyObservers();*/
		Ant ant = Ant.getAnt();
		ant.Move(dCmpSize.getWidth(),  dCmpSize.getHeight(), time );
		ant.setFoodLevel(ant.getFoodLevel() - ant.getFoodConsumptionRate());
		
		IIterator objects = gameObjects.getIterator();
		while(objects.hasNext()) {
			GameObject Object = (GameObject) objects.getNext();
			if(Object instanceof Spider) {
				Spider spider = (Spider) Object;
				spider.Move(dCmpSize.getWidth(), dCmpSize.getHeight(), time);
			}
		}
		this.setClock(clock + 1);
		this.Lives();
		this.checkCollision();
		if (gettoggleSound()) {
			stepSound.play();
		} else {
			stepSound.pause();
		}
		System.out.println("checked the collision method");
		
		this.setChanged();
	}

	/**
	 * Game status.
	 */
	public void GameStatus() { // Display current status of game																	ctrl-shift-f to format lines
		this.Lives();
		System.out.println("Playerlives: " + getLives() + " Current Clock: " + getClock() + " Highest flag: "
				+ ant.getLastFlagReached() + " Current FoodLevel: " + ant.getFoodLevel() + " HealthLevel: "
				+ ant.getHealthLevel());
	}

	/**
	 * Spider collision.
	 *
	 * @param Spider the spider
	 */
	public void spiderCollision(Spider Spider) {
		/*IIterator objects = gameObjects.getIterator();
		while(objects.hasNext()) {
			GameObject Object = (GameObject) objects.getNext();
			if(Object instanceof Spider) {
				Spider spider = (Spider) Object;
				if(spider.getLocation().getX() == ant.getLocation().getX() && spider.getLocation().getY() == ant.getLocation().getY()) {
					ant.setHealthLevel(ant.getHealthLevel() - 1);
					ant.speedDecrease();
					ant.setColor(0, 0, 0);
					if(ant.getHealthLevel() <= 0) {
						ant.setSpeed(0);
					}
				}					//checks if spider is in same location, but for testing purposes no (Pretend)
			}
		}
		this.Lives();
		this.setChanged();
		notifyObservers();*/

		Ant ant = Ant.getAnt();
		ant.setHealthLevel(ant.getHealthLevel() - 1);															//newish
		ant.setColor(255, 100, 100);
		ant.speedDecrease();

		this.getLives();
		//new sound
		if (gettoggleSound()) {
			spiderCollideSound.play();
		} else {
			spiderCollideSound.pause();
		}
		this.setChanged();
		notifyObservers();
	}

	/**
	 * Flag collision.
	 *
	 * @param flagNumber the flag number
	 */
	public void flagCollision(int flagNumber) {						//iterate through flag count
		Ant ant = Ant.getAnt();
		if(flagNumber == ant.getLastFlagReached() + 1 ) {				//may need the +1 in if statement
			ant.setLastFlagReached(flagNumber);
			System.out.println("you're at flag: "+ flagNumber);
		}
		this.Lives();
		if (gettoggleSound()) {
			coinSound.play();
		} else {
			coinSound.pause();
		}
		this.setChanged();
		notifyObservers();
	}

	/**
	 * Food foodStation collision.
	 *
	 * @param foodstation the foodstation
	 */
	public void foodStationCollision(FoodStations foodstation) {	//FoodStations foodStation
		/*IIterator objects = gameObjects.getIterator();
		int cap = 0;
		while(objects.hasNext()) {
			GameObject Object = (GameObject) objects.getNext();
			if(Object instanceof FoodStations) {
				FoodStations foodStation = (FoodStations) Object;
				System.out.println("reach here if gets to food COLISION");
				ant.setFoodLevel(ant.getFoodLevel() + cap);
				cap = foodStation.getCapacity();
				foodStation.setCapacity(0);
				foodStation.setColor(0, 150, 0);
				System.out.println("collided with Food");
				break;
			}
		}
		Ant ant = Ant.getAnt();
		//ant.setFoodLevel(ant.getFoodLevel() + cap);					/////////////redone
		this.setChanged();
		notifyObservers();*/
		int capacity = 0;																							//newish
		capacity = foodstation.getCapacity();
		
		foodstation.setColor(200, 255, 200);
		Ant ant = Ant.getAnt();
		ant.setFoodLevel(ant.getFoodLevel() + capacity);
		gameObjects.remove(foodstation);
		gameObjects.add(new FoodStations());
		
		if (gettoggleSound()) {
			biteSound.play();
		} else {
			biteSound.pause();
		}
		
		this.setChanged();
		notifyObservers();


	}

	/**
	 * Lives.
	 */
	public void Lives() {
		int life = getLives();
		if(ant.getFoodLevel() <= 0 || ant.getHealthLevel() <= 0 && life > 0) {
			this.setLives(life - 1);
			if(life == 0) {
				System.out.println("Out of lives");
				System.exit(0);
			}else {
				ant.clear();
				gameObjects.clear();
				init();
			}
		}else if(life == 0) {
			System.out.println("Out of lives");
			System.exit(0);
		}else if(ant.getLastFlagReached() == 4) {
			System.out.println("Winner!");
			System.exit(0);
		}else {
			return;
		}
	}

	/**
	 * Display objects.
	 */
	public void DisplayObjects() {         						//Displays map- location etc
		IIterator objects = gameObjects.getIterator();
		while(objects.hasNext()) 
		{
			GameObject Object = (GameObject) objects.getNext();
			if(Object instanceof Flag) {
				System.out.println("Flag: " + Object);
			}
			if(Object instanceof Ant) {
				System.out.println("Ant: " + Object);
			}
			if(Object instanceof Spider) {
				System.out.println("Spider: " + Object);
			}
			if(Object instanceof FoodStations) {
				System.out.println("Food Station: " + Object);
			}
		}
	}


}
