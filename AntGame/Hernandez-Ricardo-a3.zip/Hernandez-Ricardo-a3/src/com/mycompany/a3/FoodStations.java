package com.mycompany.a3;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Graphics;
import com.codename1.ui.geom.Point;

import java.util.Random;

/**
 * The Class FoodStations.
 *
 * @author Ricardo Hernandez
 * The Class FoodStations.
 */
public class FoodStations extends Fixed {

	/** The capacity. */
	private int capacity;

	/** The select. */
	private boolean select;

	/**
	 * Instantiates a new food stations.
	 */
	public FoodStations() {
		super(getRandomInt(5, 15), getRandomFloat((float)1000, (float)0),getRandomFloat((float)1000, (float)0), ColorUtil.rgb(0, 255, 0));
		this.capacity = super.getSize();
	}

	/*public boolean isEmpty() {
		if(capacity == 0) {
			return true;
		}
		return false;
	}*/

	/**
	 * Gets the random int.
	 *
	 * @param min the min
	 * @param max the max
	 * @return the random int
	 */
	public static int getRandomInt(int min, int max) {
		Random rand = new Random();
		return min + rand.nextInt(max - min);
	}

	/**
	 * Gets the random float.
	 *
	 * @param max the max
	 * @param min the min
	 * @return the random float
	 */
	public static float getRandomFloat(float max, float min) {
		Random rand = new Random();
		float b = min+ (max - min) * rand.nextFloat();
		return (float)(Math.round(b*10.0)/10.0);			//round the float number
	}

	/**
	 * Gets the capacity.
	 *
	 * @return the capacity
	 */
	public int getCapacity() {
		return capacity;
	}

	/**
	 * Sets the capacity.
	 *
	 * @param capacity the new capacity
	 */
	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}

	/* (non-Javadoc)
	 * @see com.mycompany.a3.ISelectable#setSelected(boolean)
	 */
	@Override
	public void setSelected(boolean b) {
		// TODO Auto-generated method stub
		this.select = b;

	}

	/* (non-Javadoc)
	 * @see com.mycompany.a3.ISelectable#isSelected()
	 */
	@Override
	public boolean isSelected() {
		// TODO Auto-generated method stub
		return select;
	}

	/* (non-Javadoc)
	 * @see com.mycompany.a3.ISelectable#contains(com.codename1.ui.geom.Point, com.codename1.ui.geom.Point)
	 */
	@Override
	public boolean contains(Point pPtrRelPrnt, Point pCmpRelPrnt) {
		// TODO Auto-generated method stub
		int px = pPtrRelPrnt.getX();
		int py = pPtrRelPrnt.getY();
		int locx = pCmpRelPrnt.getX() + (int) getLocation().getX();
		int locy = pCmpRelPrnt.getY() + (int) getLocation().getY();
		if((px >= locx - getSize() / 2) && (px <= locx + getSize() / 2) && (py >= locy - getSize() / 2) && (py <= locy + getSize() / 2)) {
			return true;
		}else {
			return false;
		}
	}

	/* (non-Javadoc)
	 * @see com.mycompany.a3.IDrawable#draw(com.codename1.ui.Graphics, com.codename1.ui.geom.Point)
	 */
	@Override
	public void draw(Graphics g, Point pCmpRelPrnt) {
		// TODO Auto-generated method stub
		int x =(int) getLocation().getX() + pCmpRelPrnt.getX() - getSize() / 2;
		int y =(int) getLocation().getY() + pCmpRelPrnt.getY() - getSize() / 2;
		g.setColor(ColorUtil.BLACK);
		g.drawString(Integer.toString(getCapacity()), x + getSize() / 4, y - getSize() / 9);		//draws integers on figure
		g.setAlpha(100);
		g.setColor(getColor());
		if(!isSelected()) {
			g.fillRect(x, y, getSize() * 4, getSize() * 4);
		}
		else {
			g.drawRect(x,  y, super.getSize() * 4, super.getSize() * 4);
		}
		g.setAlpha(255);;
		
	}

	/* (non-Javadoc)
	 * @see com.mycompany.a3.GameObject#collidesWith(com.mycompany.a3.GameObject)
	 */
	@Override
	public boolean collidesWith(GameObject anotherObject) {
		boolean res = false;
		int x1 = (int) getLocation().getX();
		int y1 = (int) getLocation().getY();
		int x2 = (int) anotherObject.getLocation().getX();
		int y2 = (int) anotherObject.getLocation().getY();

		int radius1 = this.getSize() / 2;
		int radius2 = this.getSize() / 2;
		int distanceX = x1 - x2;
		int distanceY = y1 - y2;

		int centerDistance = ((distanceX * distanceX) + (distanceY * distanceY));
		int radSqr = ((radius1 * radius1) + (2 * radius1 * radius2) + (radius2 * radius2));

		if(centerDistance <= radSqr) {
			res = true;
		}
		return res;
	}

	/* (non-Javadoc)
	 * @see com.mycompany.a3.GameObject#handleCollision(com.mycompany.a3.GameObject, com.mycompany.a3.GameWorld)
	 */
	@Override
	public void handleCollision(GameObject anotherObject, GameWorld gw) {
		// TODO Auto-generated method stub

	}
}
