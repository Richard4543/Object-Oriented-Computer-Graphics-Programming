package com.mycompany.a3;

import com.codename1.ui.Graphics;
import com.codename1.ui.geom.Point;

/**
 * The Interface IDrawable.
 */
public interface IDrawable {

	/**
	 * Draw.
	 *
	 * @param g the g
	 * @param pCmpRelPrnt the cmp rel prnt
	 */
	public void draw(Graphics g, Point pCmpRelPrnt);

}
