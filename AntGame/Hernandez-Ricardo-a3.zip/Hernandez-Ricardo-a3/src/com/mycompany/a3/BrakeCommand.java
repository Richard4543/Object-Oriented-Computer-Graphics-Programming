package com.mycompany.a3;

import com.codename1.ui.Command;
import com.codename1.ui.events.ActionEvent;

/**
 * The Class BrakeCommand.
 */
public class BrakeCommand extends Command {

	/** The gw. */
	private GameWorld gw;
	
	/**
	 * Instantiates a new brake command.
	 *
	 * @param gw the gw
	 */
	public BrakeCommand(GameWorld gw) {
		super("Braking");
		this.gw = gw;
	}
	
	/* (non-Javadoc)
	 * @see com.codename1.ui.Command#actionPerformed(com.codename1.ui.events.ActionEvent)
	 */
	@Override
	public void actionPerformed(ActionEvent Events){
		gw.brake();
	}
}
