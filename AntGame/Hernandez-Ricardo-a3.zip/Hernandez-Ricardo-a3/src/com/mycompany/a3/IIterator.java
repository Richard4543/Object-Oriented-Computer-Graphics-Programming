 package com.mycompany.a3;

/**
 * The Interface IIterator.
 */
public interface IIterator {

		/**
		 * Checks for next.
		 *
		 * @return true, if successful
		 */
		public boolean hasNext();
		
		/**
		 * Next.
		 *	return next in collection
		 * @return the object
		 */
		public Object getNext();	
}
