package com.mycompany.a3;
import java.util.Random;
import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Graphics;
import com.codename1.ui.geom.Point;
import java.util.Vector;

/**
 * The Class Ant.
 *
 * @author Ricardo Hernandez
 * The Class Ant.
 */
public class Ant extends Moveable implements ISteerable{

	/** The food consumption. */
	private int foodConsumption;

	/** The food level. */
	private int foodLevel;

	/** The health level. */
	private int healthLevel;

	/** The last flag reached. */
	private int lastFlagReached;

	/** The maximum speed. */
	private int maximumSpeed;

	/** The ant. */
	private static Ant ant;
	
	//private GameObjectCollection gameObjects;

	/**
	 * Instantiates a new ant.
	 */
	public Ant() {
		//getRandomInt- grab method from spider class
		super(0, getRandomInt(7, 1), 40, (float)0.0, (float)0.0, ColorUtil.rgb(255,  0,  0));
		this.lastFlagReached = 1;
		this.maximumSpeed = 30;
		this.foodLevel = 50;
		this.foodConsumption = 1;
		this.healthLevel = 30;
	}

	/**
	 * Gets the random int.
	 *
	 * @param max the max
	 * @param min the min
	 * @return the random int
	 */
	public static int getRandomInt(int max, int min) {
		Random rand = new Random();
		return min + rand.nextInt(max - min);
	}

	/* (non-Javadoc)
	 * @see com.mycompany.a3.IDrawable#draw(com.codename1.ui.Graphics, com.codename1.ui.geom.Point)
	 */
	@Override
	public void draw(Graphics g, Point pCmpRelPrnt) {
		g.setColor(getColor());

		int x = (int)(getLocation().getX() - (getSize() / 2)) + pCmpRelPrnt.getX();
		int y = (int)(getLocation().getY() - (getSize() / 2)) + pCmpRelPrnt.getY();
		//		g.fillPolygon(x, y, 3);
		g.fillArc(x, y, getSize(), getSize(), 0, 360);
		
	}

	/**
	 * Change heading.
	 *
	 * @param direction the direction
	 */
	@Override
	public void changeHeading(char direction) {
		if(direction == 'l') {
			super.setHeading((int) (super.getHeading() - Math.toDegrees(5)));		//change direction of ant by -5 degrees
		}else if(direction == 'r') {
			super.setHeading((int) (super.getHeading() + Math.toDegrees(5)));		//change direction of ant by +5 degrees
		}
	}

	/* (non-Javadoc)
	 * @see com.mycompany.a3.Moveable#Move(double, double)
	 */
	/*
	 * Move for Ant
	 */
	@Override
	public void Move(double width, double height, double time) {
		double min = 0.0;
		
		double distance = (super.getSpeed() * time) / 1000;
		//double max = 1000.0;
		double theta = Math.toRadians(90 - super.getHeading());
		double deltaX = (double) (Math.cos(Math.toRadians(theta)) * distance) + super.getLocation().getX(); 
		double deltaY = (double) (Math.sin(Math.toRadians(theta)) * distance) + super.getLocation().getY();
		if(foodLevel <= 0 || healthLevel <= 0 || super.getSpeed() <= 0) {		//checks if levels are above 0
			return;
		}

		if (deltaX < min || deltaX > width || deltaY < min || deltaY > height) {		//checks bounds of height and width (size of map now)
			super.setHeading((int) (super.getHeading() + Math.toDegrees(35)));
		}
		super.setLocation((float) deltaX, (float) deltaY);
	}

	/**
	 * Gets the ant.
	 *
	 * @return the ant
	 */
	public static Ant getAnt() {
		if(ant == null) {
			ant = new Ant();
		}
		return ant;
	}

	/**
	 * Clear.
	 */
	public void clear() {
		ant = null;
	}

	/**
	 * Speed increase.
	 */
	public void speedIncrease() {
		if(super.getSpeed() == maximumSpeed | foodLevel == 0 | healthLevel == 0) {
			return;
		}else {
			super.setSpeed(super.getSpeed() + 1);
		}
	}

	/**
	 * Speed decrease.
	 */
	public void speedDecrease() {
		if(super.getSpeed() == 0) {
			return;
		}else {
			super.setSpeed(super.getSpeed() - 1);
		}
	}

	/* (non-Javadoc)
	 * @see com.mycompany.a3.GameObject#handleCollision(com.mycompany.a3.GameObject, com.mycompany.a3.GameWorld)
	 */
	@Override
	public void handleCollision(GameObject anotherObject, GameWorld gw) {
		// TODO Auto-generated method stub

			System.out.println("reach here if enters handle");
			if(anotherObject instanceof Spider) {	
				gw.spiderCollision((Spider) anotherObject);
			}
			else if (anotherObject instanceof FoodStations) {
				System.out.println("reach here if enterd FOOOOD");
				gw.foodStationCollision((FoodStations) anotherObject);
			} 
			else if (anotherObject instanceof Flag) {
				gw.flagCollision(((Flag) anotherObject).getSequenceNumber());
			}
	}

	/* (non-Javadoc)
	 * @see com.mycompany.a3.GameObject#collidesWith(com.mycompany.a3.GameObject)
	 */
	@Override
	public boolean collidesWith(GameObject anotherObject) {
		System.out.println("checked the collision COllideswith");
		boolean res = false;
		int x1 = (int) getLocation().getX();
		int y1 = (int) getLocation().getY();
		int x2 = (int) anotherObject.getLocation().getX();
		int y2 = (int) anotherObject.getLocation().getY();

		int radius1 = this.getSize() / 2;
		int radius2 = this.getSize() / 2;
		int distanceX = x1 - x2;
		int distanceY = y1 - y2;

		int centerDistance = ((distanceX * distanceX) + (distanceY * distanceY));
		int radSqr = ((radius1 * radius1) + (2 * radius1 * radius2) + (radius2 * radius2));

		if(centerDistance <= radSqr) {
			res = true;
		}
		return res;
	}

	/**
	 * Gets the health level.
	 *
	 * @return the health level
	 */
	public int getHealthLevel() {
		return healthLevel;
	}


	/**
	 * Gets the food level.
	 *
	 * @return the food level
	 */
	public int getFoodLevel(){
		return foodLevel;
	}

	/**
	 * Gets the food consumption rate.
	 *
	 * @return the food consumption rate
	 */
	public int getFoodConsumptionRate() {
		return foodConsumption;
	}

	/**
	 * Gets the max speed.
	 *
	 * @return the max speed
	 */
	public int getMaxSpeed() {
		return maximumSpeed;
	}

	/**
	 * Gets the last flag reached.
	 *
	 * @return the last flag reached
	 */
	public int getLastFlagReached() {
		return lastFlagReached;
	}

	/**
	 * Sets the last flag reached.
	 *
	 * @param lastFlagReached the new last flag reached
	 */
	public void setLastFlagReached(int lastFlagReached) {
		this.lastFlagReached = lastFlagReached;
	}

	/**
	 * Sets the food level.
	 *
	 * @param foodLevel the new food level
	 */
	public void setFoodLevel(int foodLevel) {
		this.foodLevel = foodLevel;
	}

	/**
	 * Sets the max speed.
	 *
	 * @param maximumSpeed the new max speed
	 */
	public void setMaxSpeed(int maximumSpeed) {
		this.maximumSpeed = maximumSpeed;
	}

	/**
	 * Sets the health level.
	 *
	 * @param healthLevel the new health level
	 */
	public void setHealthLevel(int healthLevel) {
		this.healthLevel = healthLevel;
	}

	/**
	 * Sets the food consumption rate.
	 *
	 * @param foodConsumption the new food consumption rate
	 */
	public void setFoodConsumptionRate(int foodConsumption) {
		this.foodConsumption = foodConsumption;
	}

	/* (non-Javadoc)
	 * @see com.mycompany.a3.Moveable#toString()
	 */
	/*
	 * toString
	 * @Overide
	 */
	public String toString() {
		String parentDesc = super.toString();
		String myDesc = 
				" Max Speed: " + this.maximumSpeed + " Food Consumption: " + this.foodConsumption + " Ant last flag reaches: " + this.lastFlagReached;
		return parentDesc + myDesc;
	}

}
