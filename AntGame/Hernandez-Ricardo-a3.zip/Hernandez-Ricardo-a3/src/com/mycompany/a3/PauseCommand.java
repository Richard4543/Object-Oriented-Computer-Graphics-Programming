package com.mycompany.a3;

import com.codename1.ui.Command;
import com.codename1.ui.events.ActionEvent;

/**
 * The Class PauseCommand.
 */
public class PauseCommand extends Command {
	
	/** The g. */
	private Game g;

	/**
	 * Instantiates a new pause command.
	 *
	 * @param g the g
	 */
	public PauseCommand(Game g) {
		super("pause");
		this.g = g;
	}

	/* (non-Javadoc)
	 * @see com.codename1.ui.Command#actionPerformed(com.codename1.ui.events.ActionEvent)
	 */
	@Override
	public void actionPerformed(ActionEvent Events) {
		if(!g.isPaused()) {
		g.pauseGame();
		}
		else {
		System.out.println("paused");
		g.play();
		}
	}
}
