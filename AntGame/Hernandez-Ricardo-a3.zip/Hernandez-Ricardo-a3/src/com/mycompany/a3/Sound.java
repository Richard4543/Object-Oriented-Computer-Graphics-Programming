package com.mycompany.a3;

import java.io.InputStream; 
import com.codename1.media.Media;
import com.codename1.media.MediaManager;
import com.codename1.ui.Display;


/**
 * The Class Sound.
 */
public class Sound {
	
	/** The m. */
	private Media m;
	
	/**
	 * Instantiates a new sound.
	 *
	 * @param fileName the file name
	 */
	public Sound(String fileName) {
		try
		{
			InputStream in = Display.getInstance().getResourceAsStream(getClass(), "/" + fileName);
			m  = MediaManager.createMedia(in, "audio/wav");
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	/**
	 * Play.
	 */
	public void play()
	{
		m.setTime(0);
		m.setVolume(15);
		m.play();
	}
	
	/**
	 * Pause.
	 */
	public void pause()
	{
		m.setTime(0);
		m.pause();
	}
}