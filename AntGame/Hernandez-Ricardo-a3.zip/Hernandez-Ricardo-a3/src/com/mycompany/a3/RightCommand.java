package com.mycompany.a3;

import com.codename1.ui.Command;
import com.codename1.ui.events.ActionEvent;

/**
 * The Class RightCommand.
 */
public class RightCommand extends Command {

	/** The gw. */
	private GameWorld gw;
	
	/**
	 * Instantiates a new right command.
	 *
	 * @param gw the gw
	 */
	public RightCommand(GameWorld gw) {
		super("Right");
		this.gw = gw;
	}
	
	/* (non-Javadoc)
	 * @see com.codename1.ui.Command#actionPerformed(com.codename1.ui.events.ActionEvent)
	 */
	@Override
	public void actionPerformed(ActionEvent Events){
		gw.changeHeading('r');
	}
}