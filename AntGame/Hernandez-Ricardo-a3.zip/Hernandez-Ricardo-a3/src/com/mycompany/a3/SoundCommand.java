package com.mycompany.a3;

import com.codename1.ui.CheckBox;
import com.codename1.ui.Command;
import com.codename1.ui.events.ActionEvent;

/**
 * The Class AccelerateCommand.
 */
public class SoundCommand extends Command {

	/** The gw. */
	private GameWorld gw;
	private CheckBox soundOn;
	
	/**
	 * Instantiates a new accelerate command.
	 *
	 * @param gw the gw
	 * @param soundOn 
	 */
	public SoundCommand(GameWorld gw, CheckBox soundOn) {
		super("Sound");
		this.gw = gw;
		this.soundOn = soundOn;
	}
	
	/* (non-Javadoc)
	 * @see com.codename1.ui.Command#actionPerformed(com.codename1.ui.events.ActionEvent)
	 */
	@Override
	public void actionPerformed(ActionEvent Events){
		
		if(soundOn.isSelected()) {
			gw.toggleSound(true);
			System.out.println("Sound: On");
		}
		else {
			gw.toggleSound(false);
			System.out.println("Sound: Off");
		}
		
		
		
	}
}
