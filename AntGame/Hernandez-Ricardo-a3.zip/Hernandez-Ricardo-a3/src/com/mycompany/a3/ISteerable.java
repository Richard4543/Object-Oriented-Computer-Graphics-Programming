package com.mycompany.a3;

/**@author Ricardo Hernandez
 * The Interface ISteerable.
 */
public interface ISteerable {
	
	/**
	 * Change heading.
	 *
	 * @param direction the direction
	 */
	public void changeHeading(char direction);
	
	/**
	 * Speed increase.
	 */
	public void speedIncrease();
	
	/**
	 * Speed decrease.
	 */
	public void speedDecrease();
}
